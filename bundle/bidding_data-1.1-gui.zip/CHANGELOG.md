
JFR Pary - dane licytacji: lista zmian
======================================

1.1rc1 (2016-10-24)
* obsługa Gońca
* zapamiętywanie wypełnionych wartości (ścieżek + konf. Gońca)

1.0.3 (2015-11-14)
* obsługa usuwania licytacji sprzed usunięcia całego rozdania
* poprawki inicjalizacji listy przetwarzanych plików
* obsługa wyświetlania pominiętych licytujących

1.0.2 (2015-10-27)
* wersja z interfejsem graficznym

1.0.1 (2015-09-13)
* logowanie danych diagnostycznych
* poprawki kodowania protokołów

1.0.0 (2015-09-01)
* pierwotna wersja programu
