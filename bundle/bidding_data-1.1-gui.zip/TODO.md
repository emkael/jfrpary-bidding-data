 * pobieranie nazwisk z BWS
   - w jakiej kolejności?
 * obsługa opisu rozdań, w których nie ma licytacji
   - kiedy? (np. gdy są już zapisy z rundy+1? co z ostatnią rundą?)
