 * pobieranie nazwisk z BWS(?)
