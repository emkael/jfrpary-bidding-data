 * czyszczenie nieużywanych plików *_bidding_*.txt
 * pobieranie nazwisk z BWS(?)
