
JFR Pary - dane licytacji: lista zmian
======================================

1.0.1 (2015-09-05)
* poprawki kodowania protokołów

1.0.0 (2015-09-01)
* pierwotna wersja programu
